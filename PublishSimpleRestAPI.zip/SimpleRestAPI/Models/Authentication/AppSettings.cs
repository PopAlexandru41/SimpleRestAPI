﻿namespace SimpleRestAPI.Models.Authentication
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
