﻿namespace SimpleRestAPI
{
    public class Constants
    {
        public const string CreateUserMessage = "User was Added";
        public const string DeleteUserMessage = "User was Delete";
        public const string UpdateUserMessage = "User was Updated";

        public const string CreateStudentsMessage = "Students was Added";
        public const string DeleteStudentsMessage = "Students was Delete";
        public const string UpdateStudentsMessage = "Students was Updated";
    }
}
